"""Vercel entry point. Vercel's Python runtime looks for an ASGI `app` in api/index.py."""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.main import app  # noqa: E402,F401
