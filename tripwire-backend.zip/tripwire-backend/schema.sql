-- Run this once in Supabase: SQL Editor > New query > paste > Run.
-- Tables use text ids so accounts keep the codes your bank uses.

create table if not exists accounts (
  id            text primary key,
  name          text not null,
  kind          text not null check (kind in ('retail','merchant','business','mule')),
  home_city     text not null,
  mu            double precision not null default 7.6,
  var           double precision not null default 0.36,
  balance       double precision not null default 0,
  devices       jsonb not null default '[]'::jsonb,
  payees        jsonb not null default '[]'::jsonb,
  last_city     text,
  last_ts       timestamptz,
  frozen        boolean not null default false,
  created_at    timestamptz not null default now()
);

create table if not exists cases (
  id            uuid primary key default gen_random_uuid(),
  kind          text not null,
  status        text not null default 'open' check (status in ('open','escalated','confirmed','cleared')),
  max_score     double precision not null default 0,
  value         double precision not null default 0,
  opened_at     timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists case_accounts (
  case_id       uuid references cases(id) on delete cascade,
  account_id    text references accounts(id) on delete cascade,
  primary key (case_id, account_id)
);

create table if not exists transactions (
  id              uuid primary key default gen_random_uuid(),
  from_account    text not null references accounts(id),
  to_account      text not null references accounts(id),
  amount          double precision not null check (amount > 0),
  channel         text not null,
  device_id       text not null,
  city            text not null,
  score           double precision not null,
  decision        text not null check (decision in ('allow','step_up','hold','block')),
  factors         jsonb not null default '[]'::jsonb,
  baseline_flag   boolean not null default false,
  is_fraud_label  boolean,
  case_id         uuid references cases(id),
  created_at      timestamptz not null default now()
);

create table if not exists watchlist (
  account_id    text primary key references accounts(id) on delete cascade,
  reason        text not null,
  added_at      timestamptz not null default now()
);

create index if not exists tx_from_time on transactions (from_account, created_at desc);
create index if not exists tx_to_time   on transactions (to_account, created_at desc);
create index if not exists tx_case      on transactions (case_id);
create index if not exists tx_label     on transactions (is_fraud_label);

-- Only the backend talks to these tables, using the service role key.
-- Enable row level security so the public anon key cannot read or write them.
alter table accounts      enable row level security;
alter table cases         enable row level security;
alter table case_accounts enable row level security;
alter table transactions  enable row level security;
alter table watchlist     enable row level security;
