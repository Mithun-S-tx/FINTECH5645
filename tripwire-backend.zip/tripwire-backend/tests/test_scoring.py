from datetime import datetime, timedelta, timezone

from app.scoring import AccountProfile, Context, PaymentInput, decide, score_payment
from app.service import CITY_COORDS

NOW = datetime(2026, 10, 13, 10, 0, tzinfo=timezone.utc)


def profile(**over) -> AccountProfile:
    base = dict(id="AC-1", kind="retail", home_city="Mumbai", mu=7.6, var=0.36,
                devices={"D-home"}, payees={"M-1"}, balance=200_000, last_city="Mumbai",
                last_ts=NOW - timedelta(hours=6), age_days=900)
    base.update(over)
    return AccountProfile(**base)


def payee(**over) -> AccountProfile:
    base = dict(id="M-1", kind="merchant", home_city="Delhi", mu=7.6, var=0.36, balance=1e6, age_days=2000)
    base.update(over)
    return AccountProfile(**base)


def test_normal_payment_is_allowed():
    s = score_payment(PaymentInput(800, "D-home", "Mumbai", "UPI"), profile(), payee(),
                      Context(now=NOW), CITY_COORDS)
    assert s.score < 35
    assert decide(s.score, frozen=False, step_up=35, hold=60, block=85) == "allow"


def test_takeover_pattern_is_held_or_blocked():
    ctx = Context(now=NOW, sender_outflows_10m=3, payee_senders_30m=1, payee_age_days=4)
    ratio_amount = 90_000
    s = score_payment(
        PaymentInput(ratio_amount, "D-new", "Dubai", "IMPS"),
        profile(last_city="Mumbai", last_ts=NOW - timedelta(minutes=5)),
        payee(id="AC-MULE", kind="mule", age_days=4),
        Context(now=NOW, sender_outflows_10m=3, payee_age_days=4, payee_senders_30m=1),
        CITY_COORDS,
    )
    keys = {f.key for f in s.factors}
    assert {"device", "geo", "payee", "payee_age"} <= keys
    assert s.score >= 60, s.score
    assert decide(s.score, frozen=False, step_up=35, hold=60, block=85) in ("hold", "block")


def test_structuring_just_under_limit_is_flagged():
    s = score_payment(PaymentInput(98_500, "D-home", "Mumbai", "NEFT"), profile(), payee(kind="business"),
                      Context(now=NOW, sender_near_limit_1h=4), CITY_COORDS)
    assert "near_limit" in {f.key for f in s.factors}


def test_circular_transfer_adds_cycle_factor():
    s = score_payment(PaymentInput(50_000, "D-home", "Mumbai", "IMPS"), profile(), payee(kind="mule"),
                      Context(now=NOW, cycle_hops=2), CITY_COORDS)
    assert "cycle" in {f.key for f in s.factors}


def test_merchant_fan_in_is_not_penalised():
    s = score_payment(PaymentInput(500, "D-home", "Mumbai", "UPI"), profile(), payee(),
                      Context(now=NOW, payee_senders_30m=9, payee_is_merchant=True), CITY_COORDS)
    assert "fan_in" not in {f.key for f in s.factors}


def test_frozen_account_is_always_blocked():
    assert decide(5, frozen=True, step_up=35, hold=60, block=85) == "block"


def test_factors_are_sorted_by_weight():
    s = score_payment(PaymentInput(90_000, "D-new", "Dubai", "IMPS"), profile(), payee(age_days=3),
                      Context(now=NOW, payee_age_days=3, sender_near_limit_1h=2), CITY_COORDS)
    points = [f.points for f in s.factors]
    assert points == sorted(points, reverse=True)
