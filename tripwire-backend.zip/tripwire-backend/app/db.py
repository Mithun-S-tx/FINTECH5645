"""Supabase access. All SQL-facing code lives here so services stay storage-agnostic."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from functools import lru_cache
from typing import Any, Optional

from supabase import Client, create_client

from .config import settings


@lru_cache(maxsize=1)
def client() -> Client:
    if not settings.supabase_url or not settings.supabase_key:
        raise RuntimeError("SUPABASE_URL and SUPABASE_SERVICE_KEY must be set")
    return create_client(settings.supabase_url, settings.supabase_key)


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def parse_ts(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


# ---------- accounts ----------

def get_account(account_id: str) -> Optional[dict[str, Any]]:
    res = client().table("accounts").select("*").eq("id", account_id).limit(1).execute()
    return res.data[0] if res.data else None


def create_account(row: dict[str, Any]) -> dict[str, Any]:
    return client().table("accounts").insert(row).execute().data[0]


def update_account(account_id: str, patch: dict[str, Any]) -> None:
    client().table("accounts").update(patch).eq("id", account_id).execute()


def payee_is_merchant(account_id: str) -> bool:
    row = get_account(account_id)
    return bool(row and row["kind"] == "merchant")


# ---------- transactions ----------

def insert_transaction(row: dict[str, Any]) -> dict[str, Any]:
    return client().table("transactions").insert(row).execute().data[0]


def update_transaction(tx_id: str, patch: dict[str, Any]) -> None:
    client().table("transactions").update(patch).eq("id", tx_id).execute()


def get_transaction(tx_id: str) -> Optional[dict[str, Any]]:
    res = client().table("transactions").select("*").eq("id", tx_id).limit(1).execute()
    return res.data[0] if res.data else None


def list_transactions(limit: int) -> list[dict[str, Any]]:
    res = client().table("transactions").select("*").order("created_at", desc=True).limit(limit).execute()
    return res.data


def outflows_since(account_id: str, since: datetime) -> list[dict[str, Any]]:
    res = (
        client().table("transactions").select("*")
        .eq("from_account", account_id).gte("created_at", iso(since))
        .in_("decision", ["allow", "step_up"])
        .execute()
    )
    return res.data


def inflows_since(account_id: str, since: datetime) -> list[dict[str, Any]]:
    res = (
        client().table("transactions").select("*")
        .eq("to_account", account_id).gte("created_at", iso(since))
        .in_("decision", ["allow", "step_up"])
        .execute()
    )
    return res.data


def senders_to_payee_since(payee_id: str, since: datetime) -> set[str]:
    res = (
        client().table("transactions").select("from_account")
        .eq("to_account", payee_id).gte("created_at", iso(since))
        .execute()
    )
    return {r["from_account"] for r in res.data}


def labelled_transactions(limit: int = 10_000) -> list[dict[str, Any]]:
    res = (
        client().table("transactions").select("decision,baseline_flag,is_fraud_label,amount")
        .not_.is_("is_fraud_label", "null").limit(limit).execute()
    )
    return res.data


# ---------- watchlist ----------

def is_watched(account_id: str) -> bool:
    res = client().table("watchlist").select("account_id").eq("account_id", account_id).limit(1).execute()
    return bool(res.data)


def add_watch(account_id: str, reason: str) -> None:
    client().table("watchlist").upsert({"account_id": account_id, "reason": reason, "added_at": iso(now_utc())}).execute()


def remove_watch(account_ids: list[str]) -> None:
    for account_id in account_ids:
        client().table("watchlist").delete().eq("account_id", account_id).execute()


def freeze(account_ids: list[str]) -> None:
    for account_id in account_ids:
        client().table("accounts").update({"frozen": True}).eq("id", account_id).execute()


def unfreeze(account_ids: list[str]) -> None:
    for account_id in account_ids:
        client().table("accounts").update({"frozen": False}).eq("id", account_id).execute()


# ---------- cases ----------

def open_case_for(account_id: str) -> Optional[dict[str, Any]]:
    links = client().table("case_accounts").select("case_id").eq("account_id", account_id).execute().data
    for link in links:
        case = get_case(link["case_id"])
        if case and case["status"] in ("open", "escalated"):
            return case
    return None


def get_case(case_id: str) -> Optional[dict[str, Any]]:
    res = client().table("cases").select("*").eq("id", case_id).limit(1).execute()
    return res.data[0] if res.data else None


def create_case(row: dict[str, Any]) -> dict[str, Any]:
    return client().table("cases").insert(row).execute().data[0]


def update_case(case_id: str, patch: dict[str, Any]) -> None:
    client().table("cases").update(patch).eq("id", case_id).execute()


def link_case_accounts(case_id: str, account_ids: list[str]) -> None:
    rows = [{"case_id": case_id, "account_id": a} for a in set(account_ids)]
    client().table("case_accounts").upsert(rows, on_conflict="case_id,account_id").execute()


def case_account_ids(case_id: str) -> list[str]:
    res = client().table("case_accounts").select("account_id").eq("case_id", case_id).execute()
    return [r["account_id"] for r in res.data]


def list_cases(status: Optional[str], limit: int) -> list[dict[str, Any]]:
    q = client().table("cases").select("*").order("updated_at", desc=True).limit(limit)
    if status:
        q = q.eq("status", status)
    return q.execute().data


def case_transactions(case_id: str) -> list[dict[str, Any]]:
    res = client().table("transactions").select("*").eq("case_id", case_id).order("created_at").execute()
    return res.data


def recent_window(minutes: int) -> datetime:
    return now_utc() - timedelta(minutes=minutes)
