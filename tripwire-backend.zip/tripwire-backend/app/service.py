"""Use cases: score a payment, store it, open cases, act on cases, compute metrics.

This is where the scoring logic meets the database. Keep HTTP details out of here.
"""
from __future__ import annotations

import math
from collections import Counter
from datetime import timedelta
from typing import Any, Optional

from . import db
from .config import settings
from .scoring import AccountProfile, Context, PaymentInput, decide, score_payment

# Approximate city centres, used for the impossible-travel check. Extend as you add cities.
CITY_COORDS: dict[str, tuple[float, float]] = {
    "Mumbai": (19.08, 72.88), "Delhi": (28.61, 77.21), "Bengaluru": (12.97, 77.59),
    "Chennai": (13.08, 80.27), "Hyderabad": (17.39, 78.49), "Kolkata": (22.57, 88.36),
    "Pune": (18.52, 73.86), "Ahmedabad": (23.02, 72.57), "Dubai": (25.2, 55.27), "Singapore": (1.35, 103.82),
}


class NotFound(Exception):
    pass


class Conflict(Exception):
    pass


def _profile(row: dict[str, Any]) -> AccountProfile:
    created = db.parse_ts(row.get("created_at"))
    age = (db.now_utc() - created).days if created else 0
    return AccountProfile(
        id=row["id"],
        kind=row["kind"],
        home_city=row["home_city"],
        mu=float(row["mu"]),
        var=float(row["var"]),
        devices=set(row.get("devices") or []),
        payees=set(row.get("payees") or []),
        balance=float(row["balance"]),
        last_city=row.get("last_city"),
        last_ts=db.parse_ts(row.get("last_ts")),
        age_days=age,
    )


def _cycle_hops(sender: str, payee: str) -> int:
    """Depth-first search for a path payee -> ... -> sender in the last 30 minutes, depth up to 4."""
    since = db.recent_window(30)
    frontier = [(payee, 0)]
    seen = {payee}
    while frontier:
        node, depth = frontier.pop()
        if depth >= 4:
            continue
        for tx in db.outflows_since(node, since):
            nxt = tx["to_account"]
            if nxt == sender:
                return depth + 1
            if nxt not in seen:
                seen.add(nxt)
                frontier.append((nxt, depth + 1))
    return 0


def _context(sender: str, payee: str, payee_row: dict[str, Any], now) -> Context:
    ten_min = db.recent_window(10)
    fifteen = db.recent_window(15)
    one_hour = db.recent_window(60)
    out10 = db.outflows_since(sender, ten_min)
    near = [t for t in db.outflows_since(sender, one_hour)
            if 0.88 * 100_000 <= float(t["amount"]) < 100_000]
    inflows = db.inflows_since(sender, fifteen)
    outflows15 = db.outflows_since(sender, fifteen)
    payee_created = db.parse_ts(payee_row.get("created_at"))
    payee_age = (now - payee_created).days if payee_created else 9999
    senders = db.senders_to_payee_since(payee, db.recent_window(30))
    first_in = min((db.parse_ts(t["created_at"]) for t in inflows), default=None)
    return Context(
        now=now,
        sender_outflows_10m=len(out10),
        sender_near_limit_1h=len(near),
        payee_senders_30m=len(senders | {sender}),
        payee_age_days=payee_age,
        inbound_15m_total=sum(float(t["amount"]) for t in inflows),
        inbound_15m_count=len(inflows),
        inbound_15m_first=first_in,
        outflow_15m_total=sum(float(t["amount"]) for t in outflows15),
        cycle_hops=_cycle_hops(sender, payee),
        sender_watched=db.is_watched(sender),
        payee_watched=db.is_watched(payee),
        payee_is_merchant=payee_row["kind"] == "merchant",
    )


def score_and_record(sender_id: str, payee_id: str, p: PaymentInput, label: Optional[bool]) -> dict[str, Any]:
    sender_row = db.get_account(sender_id)
    payee_row = db.get_account(payee_id)
    if not sender_row or not payee_row:
        raise NotFound("sender or payee account does not exist")
    decision_frozen = bool(sender_row.get("frozen") or payee_row.get("frozen"))

    sender = _profile(sender_row)
    payee = _profile(payee_row)
    now = db.now_utc()
    ctx = _context(sender_id, payee_id, payee_row, now)
    result = score_payment(p, sender, payee, ctx, CITY_COORDS)
    decision = decide(result.score, frozen=decision_frozen,
                      step_up=settings.step_up, hold=settings.hold, block=settings.block)

    tx = db.insert_transaction({
        "from_account": sender_id,
        "to_account": payee_id,
        "amount": p.amount,
        "channel": p.channel,
        "device_id": p.device_id,
        "city": p.city,
        "score": result.score,
        "decision": decision,
        "factors": [f.as_dict() for f in result.factors],
        "baseline_flag": result.baseline_flag,
        "is_fraud_label": label,
        "created_at": db.iso(now),
    })

    if decision in ("allow", "step_up"):
        _settle(sender_row, payee_row, p, now)
    else:
        _open_case(tx, sender_id, payee_id, payee_row, result, now)

    return {
        "id": tx["id"],
        "decision": decision,
        "score": result.score,
        "baseline_decision": "hold" if result.baseline_flag else "allow",
        "factors": [f.as_dict() for f in result.factors],
        "case_id": tx.get("case_id"),
    }


def _settle(sender_row: dict[str, Any], payee_row: dict[str, Any], p: PaymentInput, now) -> None:
    """Update the account profiles once a payment is released."""
    amount = p.amount
    devices = set(sender_row.get("devices") or []) | {p.device_id}
    payees = set(sender_row.get("payees") or []) | {payee_row["id"]}
    mu, var = float(sender_row["mu"]), float(sender_row["var"])
    d = math.log(max(amount, 1.0)) - mu
    db.update_account(sender_row["id"], {
        "mu": mu + 0.1 * d,
        "var": 0.9 * var + 0.1 * d * d,
        "devices": sorted(devices),
        "payees": sorted(payees),
        "balance": max(float(sender_row["balance"]) - amount, 0.0),
        "last_city": p.city,
        "last_ts": db.iso(now),
    })
    db.update_account(payee_row["id"], {"balance": float(payee_row["balance"]) + amount})


def _open_case(tx: dict[str, Any], sender: str, payee: str, payee_row: dict[str, Any], result, now) -> None:
    if payee_row["kind"] != "merchant":
        db.add_watch(sender, "held or blocked payment")
        db.add_watch(payee, "linked to held or blocked payment")
    case = db.open_case_for(sender) or db.open_case_for(payee)
    kind = _case_kind(result)
    if case is None:
        case = db.create_case({
            "kind": kind,
            "status": "open",
            "max_score": result.score,
            "value": float(tx["amount"]),
            "opened_at": db.iso(now),
            "updated_at": db.iso(now),
        })
    else:
        db.update_case(case["id"], {
            "max_score": max(float(case["max_score"]), result.score),
            "value": float(case["value"]) + float(tx["amount"]),
            "updated_at": db.iso(now),
        })
    db.link_case_accounts(case["id"], [sender, payee])
    db.update_transaction(tx["id"], {"case_id": case["id"]})
    tx["case_id"] = case["id"]


def _case_kind(result) -> str:
    keys = {f.key for f in result.factors}
    if "cycle" in keys:
        return "circular"
    if "near_limit" in keys:
        return "structuring"
    if "device" in keys and ({"geo", "combo"} & keys):
        return "account_takeover"
    if {"pass_through", "fan_in"} & keys:
        return "mule_network"
    return "anomalous_transfer"


ACTIONS = {
    "account_takeover": "Freeze outgoing payments, call the customer on their registered number, force a credential reset.",
    "structuring": "Escalate to the AML desk, aggregate the payments and prepare a suspicious transaction report.",
    "circular": "Hold every leg of the loop, flag the ring accounts and prepare a suspicious transaction report.",
    "mule_network": "Freeze the receiving account, trace onward transfers and notify the beneficiary banks.",
    "anomalous_transfer": "Review with the customer and confirm the payment purpose before release.",
}


def case_view(case: dict[str, Any]) -> dict[str, Any]:
    return {**case, "recommended_action": ACTIONS.get(case["kind"], ""), "accounts": db.case_account_ids(case["id"])}


def act_on_case(case_id: str, action: str) -> dict[str, Any]:
    case = db.get_case(case_id)
    if not case:
        raise NotFound("case does not exist")
    if case["status"] == "cleared" and action != "reopen":
        raise Conflict("case is already cleared")
    accounts = db.case_account_ids(case_id)
    now = db.iso(db.now_utc())
    if action == "confirm":
        db.freeze(accounts)
        db.update_case(case_id, {"status": "confirmed", "updated_at": now})
    elif action == "escalate":
        db.update_case(case_id, {"status": "escalated", "updated_at": now})
    elif action == "clear":
        db.unfreeze(accounts)
        db.remove_watch(accounts)
        db.update_case(case_id, {"status": "cleared", "updated_at": now})
    else:
        raise ValueError(f"unknown action {action}")
    return case_view(db.get_case(case_id))


def metrics() -> dict[str, Any]:
    rows = db.labelled_transactions()
    model, rules = Counter(), Counter()
    for r in rows:
        fraud = bool(r["is_fraud_label"])
        alert = r["decision"] != "allow"
        base = bool(r["baseline_flag"])
        for counter, flagged in ((model, alert), (rules, base)):
            if fraud and flagged:
                counter["tp"] += 1
            elif fraud:
                counter["fn"] += 1
            elif flagged:
                counter["fp"] += 1
            else:
                counter["tn"] += 1

    def ratio(a: int, b: int) -> Optional[float]:
        return round(a / (a + b), 4) if (a + b) else None

    def summarise(c: Counter) -> dict[str, Optional[float]]:
        return {
            "precision": ratio(c["tp"], c["fp"]),
            "recall": ratio(c["tp"], c["fn"]),
            "false_positive_rate": ratio(c["fp"], c["tn"]),
        }

    return {
        "labelled_payments": len(rows),
        "model": summarise(model),
        "rules_only": summarise(rules),
        "note": "Metrics use only payments that carry a fraud label. Unlabelled production traffic is excluded.",
    }
