"""HTTP API for Tripwire. Every route except /health needs the X-API-Key header."""
import hmac
from datetime import timedelta
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from . import db, service
from .config import settings
from .schemas import AccountCreate, CaseAction, PaymentCreate
from .scoring import PaymentInput

app = FastAPI(
    title="Tripwire API",
    version="0.1.0",
    description="Real-time payment risk scoring, AML pattern detection and case management.",
)

# The console is a static page, so allow browser calls. Tighten allow_origins to your domain before go-live.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def require_key(x_api_key: Optional[str] = Header(default=None)) -> None:
    # Fail closed: if the server has no key configured, nothing is allowed.
    if not settings.api_key or not x_api_key or not hmac.compare_digest(x_api_key, settings.api_key):
        raise HTTPException(status_code=401, detail="missing or invalid X-API-Key")


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/v1/accounts", status_code=201, dependencies=[Depends(require_key)])
def create_account(body: AccountCreate) -> dict:
    if db.get_account(body.id):
        raise HTTPException(status_code=409, detail="account already exists")
    now = db.now_utc()
    row = db.create_account({
        "id": body.id,
        "name": body.name,
        "kind": body.kind,
        "home_city": body.home_city,
        "mu": 7.6,
        "var": 0.36,
        "balance": body.opening_balance,
        "devices": [],
        "payees": [],
        "frozen": False,
        "created_at": db.iso(now - timedelta(days=body.account_age_days)),
    })
    return row


@app.get("/v1/accounts/{account_id}", dependencies=[Depends(require_key)])
def get_account(account_id: str) -> dict:
    row = db.get_account(account_id)
    if not row:
        raise HTTPException(status_code=404, detail="account not found")
    return row


@app.post("/v1/payments", status_code=201, dependencies=[Depends(require_key)])
def score_payment(body: PaymentCreate) -> dict:
    if body.from_account == body.to_account:
        raise HTTPException(status_code=422, detail="sender and payee must differ")
    try:
        return service.score_and_record(
            body.from_account,
            body.to_account,
            PaymentInput(amount=body.amount, device_id=body.device_id, city=body.city, channel=body.channel),
            body.is_fraud_label,
        )
    except service.NotFound as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.get("/v1/payments", dependencies=[Depends(require_key)])
def list_payments(limit: int = Query(default=50, ge=1, le=500)) -> list[dict]:
    return db.list_transactions(limit)


@app.get("/v1/payments/{tx_id}", dependencies=[Depends(require_key)])
def get_payment(tx_id: str) -> dict:
    row = db.get_transaction(tx_id)
    if not row:
        raise HTTPException(status_code=404, detail="payment not found")
    return row


@app.get("/v1/cases", dependencies=[Depends(require_key)])
def list_cases(status: Optional[str] = Query(default=None, pattern="^(open|escalated|confirmed|cleared)$"),
               limit: int = Query(default=50, ge=1, le=200)) -> list[dict]:
    return [service.case_view(c) for c in db.list_cases(status, limit)]


@app.get("/v1/cases/{case_id}", dependencies=[Depends(require_key)])
def get_case(case_id: str) -> dict:
    case = db.get_case(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="case not found")
    return {**service.case_view(case), "payments": db.case_transactions(case_id)}


@app.post("/v1/cases/{case_id}/actions", dependencies=[Depends(require_key)])
def case_action(case_id: str, body: CaseAction) -> dict:
    try:
        return service.act_on_case(case_id, body.action)
    except service.NotFound as e:
        raise HTTPException(status_code=404, detail=str(e))
    except service.Conflict as e:
        raise HTTPException(status_code=409, detail=str(e))


@app.get("/v1/metrics", dependencies=[Depends(require_key)])
def metrics() -> dict:
    return service.metrics()
