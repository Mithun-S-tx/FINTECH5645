from typing import Literal, Optional

from pydantic import BaseModel, Field


class AccountCreate(BaseModel):
    id: str = Field(min_length=3, max_length=64)
    name: str = Field(min_length=1, max_length=120)
    kind: Literal["retail", "merchant", "business", "mule"] = "retail"
    home_city: str = Field(min_length=2, max_length=64)
    opening_balance: float = Field(default=0, ge=0)
    account_age_days: int = Field(default=365, ge=0)


class PaymentCreate(BaseModel):
    from_account: str
    to_account: str
    amount: float = Field(gt=0, le=10_000_000)
    device_id: str = Field(min_length=1, max_length=64)
    city: str = Field(min_length=2, max_length=64)
    channel: Literal["UPI", "IMPS", "NEFT", "Card"] = "UPI"
    is_fraud_label: Optional[bool] = None  # only for evaluation data, never set by real customers


class CaseAction(BaseModel):
    action: Literal["confirm", "escalate", "clear"]
