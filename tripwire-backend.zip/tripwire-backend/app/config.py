import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


def _float(name: str, default: float) -> float:
    raw = os.getenv(name)
    return float(raw) if raw else default


@dataclass(frozen=True)
class Settings:
    supabase_url: str
    supabase_key: str
    api_key: str
    step_up: float
    hold: float
    block: float


def load_settings() -> Settings:
    return Settings(
        supabase_url=os.getenv("SUPABASE_URL", ""),
        supabase_key=os.getenv("SUPABASE_SERVICE_KEY", ""),
        api_key=os.getenv("TRIPWIRE_API_KEY", ""),
        step_up=_float("STEP_UP_THRESHOLD", 35),
        hold=_float("HOLD_THRESHOLD", 60),
        block=_float("BLOCK_THRESHOLD", 85),
    )


settings = load_settings()
