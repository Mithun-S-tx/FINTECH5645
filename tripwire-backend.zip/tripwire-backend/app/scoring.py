"""Explainable risk scoring for a single payment.

Pure functions only: no database access here, so the logic is easy to test.
The repository layer gathers the account profile and the Context, then calls score_payment.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

BIAS = -4.6
REPORT_LIMIT = 100_000.0  # INR reporting threshold used for the structuring check
EARTH_RADIUS_KM = 6371.0

FACTOR_LABELS = {
    "amount": "Unusual amount",
    "device": "New device",
    "geo": "Location jump",
    "velocity": "Payment velocity",
    "payee": "New payee",
    "payee_age": "Young payee account",
    "drain": "Balance drain",
    "near_limit": "Just under reporting limit",
    "fan_in": "Many senders, one payee",
    "pass_through": "Pass-through of funds",
    "cycle": "Money returns to origin",
    "watchlist": "Linked to watched account",
    "combo": "Device, place and payee all new",
}


@dataclass
class AccountProfile:
    id: str
    kind: str  # retail | merchant | business | mule
    home_city: str
    mu: float  # mean of log(amount) for this account's normal payments
    var: float  # variance of log(amount)
    devices: set[str] = field(default_factory=set)
    payees: set[str] = field(default_factory=set)
    balance: float = 0.0
    last_city: Optional[str] = None
    last_ts: Optional[datetime] = None
    age_days: int = 0


@dataclass
class Context:
    """Facts about recent activity, gathered by the repository before scoring."""
    now: datetime
    sender_outflows_10m: int = 0
    sender_near_limit_1h: int = 0
    payee_senders_30m: int = 1  # distinct senders paying this payee in 30 minutes, incl. this one
    payee_age_days: int = 9999
    inbound_15m_total: float = 0.0
    inbound_15m_count: int = 0
    inbound_15m_first: Optional[datetime] = None
    outflow_15m_total: float = 0.0
    cycle_hops: int = 0  # 0 means no loop back to the sender within depth 4
    sender_watched: bool = False
    payee_watched: bool = False
    payee_is_merchant: bool = False


@dataclass
class PaymentInput:
    amount: float
    device_id: str
    city: str
    channel: str


@dataclass
class Factor:
    key: str
    label: str
    points: float
    detail: str

    def as_dict(self) -> dict:
        return {"key": self.key, "label": self.label, "points": round(self.points, 2), "detail": self.detail}


@dataclass
class ScoreResult:
    score: float
    factors: list[Factor]
    baseline_flag: bool  # what a fixed rules-only system would have done, kept for comparison


def haversine_km(a: tuple[float, float], b: tuple[float, float]) -> float:
    lat1, lon1 = map(math.radians, a)
    lat2, lon2 = map(math.radians, b)
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(h))


def score_payment(
    payment: PaymentInput,
    sender: AccountProfile,
    payee: AccountProfile,
    ctx: Context,
    city_coords: dict[str, tuple[float, float]],
) -> ScoreResult:
    factors: list[Factor] = []

    def add(key: str, points: float, detail: str) -> None:
        if points > 0.05:
            factors.append(Factor(key, FACTOR_LABELS[key], points, detail))

    # Amount against this account's own history (log-normal profile).
    sd = max(math.sqrt(sender.var), 0.5)
    z = (math.log(max(payment.amount, 1.0)) - sender.mu) / sd
    typical = math.exp(sender.mu)
    add("amount", min(max((z - 1.5) * 0.9, 0.0), 3.0),
        f"Rs {payment.amount:,.0f} is {payment.amount / typical:.1f}x this customer's typical payment")

    new_device = payment.device_id not in sender.devices
    if new_device:
        add("device", 1.4, f"Device {payment.device_id} has not been seen on this account")

    new_location = payment.city != sender.home_city
    if new_location and sender.last_city and sender.last_ts:
        km = _distance(city_coords, sender.last_city, payment.city)
        hours = max((ctx.now - sender.last_ts).total_seconds() / 3600, 1 / 120)
        if km is not None and km / hours > 800:
            add("geo", 2.0, f"{sender.last_city} to {payment.city} ({km:,.0f} km) in {hours * 60:.0f} min")
        else:
            add("geo", 0.5, f"Payment made from {payment.city}, usually {sender.home_city}")
    elif new_location:
        add("geo", 0.5, f"Payment made from {payment.city}, usually {sender.home_city}")

    velocity = ctx.sender_outflows_10m + 1
    add("velocity", min(max((velocity - 2) * 0.5, 0.0), 2.0), f"{velocity} payments from this account in 10 minutes")

    new_payee = payee.id not in sender.payees
    if new_payee:
        add("payee", 0.6, f"First payment to {payee.id}")
        if ctx.payee_age_days < 30:
            add("payee_age", 0.9, f"Payee account is only {ctx.payee_age_days} days old")

    ratio = payment.amount / max(sender.balance, 1.0)
    if ratio > 0.5:
        add("drain", 1.6 if ratio > 0.8 else 1.0, f"Moves {min(ratio, 1.0) * 100:.0f}% of the available balance")

    if 0.88 * REPORT_LIMIT <= payment.amount < REPORT_LIMIT:
        prior = ctx.sender_near_limit_1h
        add("near_limit", 0.9 + 0.7 * min(prior, 4),
            f"Rs {payment.amount:,.0f} sits just under the Rs 1,00,000 limit"
            + (f", {prior} similar in the last hour" if prior else ""))

    if ctx.payee_senders_30m >= 3 and not ctx.payee_is_merchant:
        add("fan_in", min((ctx.payee_senders_30m - 2) * 0.7, 2.4),
            f"{ctx.payee_senders_30m} different senders paid {payee.id} in 30 minutes")

    if ctx.inbound_15m_total >= 5000 and ctx.inbound_15m_first:
        forwarded = payment.amount + ctx.outflow_15m_total
        share = forwarded / ctx.inbound_15m_total
        if share >= 0.8:
            minutes = (ctx.now - ctx.inbound_15m_first).total_seconds() / 60
            add("pass_through", 2.2 + (0.5 if ctx.inbound_15m_count >= 3 else 0.0),
                f"Forwards {min(share, 1.0) * 100:.0f}% of funds received {minutes:.0f} min ago")

    if ctx.cycle_hops:
        add("cycle", 3.2, f"Funds return to {sender.id} after {ctx.cycle_hops + 1} payments")

    if ctx.sender_watched or (ctx.payee_watched and not ctx.payee_is_merchant):
        add("watchlist", 1.6, "Account is already under watch")

    if new_device and new_location and new_payee:
        add("combo", 1.2, "Three first-time signals on one payment")

    factors.sort(key=lambda f: f.points, reverse=True)
    total = sum(f.points for f in factors)
    score = 100 / (1 + math.exp(-(BIAS + total)))

    baseline_flag = (
        payment.amount >= 50_000
        or velocity >= 5
        or (new_device and payment.amount >= 20_000)
    )
    return ScoreResult(score=round(score, 2), factors=factors, baseline_flag=baseline_flag)


def decide(score: float, *, frozen: bool, step_up: float, hold: float, block: float) -> str:
    if frozen or score >= block:
        return "block"
    if score >= hold:
        return "hold"
    if score >= step_up:
        return "step_up"
    return "allow"


def _distance(coords: dict[str, tuple[float, float]], a: str, b: str) -> Optional[float]:
    if a in coords and b in coords:
        return haversine_km(coords[a], coords[b])
    return None
