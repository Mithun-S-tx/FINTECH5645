# Tripwire backend

Python API for the Tripwire fraud and AML console. FastAPI runs the API, Supabase stores data, and Vercel hosts it. Code lives on GitHub.

```
api/index.py        Vercel entry point
app/main.py         HTTP routes
app/service.py      use cases: score, record, cases, metrics
app/scoring.py      pure scoring logic (no database)
app/db.py           all Supabase access
app/schemas.py      request validation
schema.sql          database tables (run once in Supabase)
tests/              scoring tests
```

## 1. Run locally

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # then fill in the Supabase values
pytest                        # scoring tests need no database
uvicorn app.main:app --reload # http://127.0.0.1:8000/docs
```

## 2. Create the Supabase database

1. Create a project at supabase.com.
2. Open **SQL Editor**, paste `schema.sql`, and run it.
3. Open **Project Settings > API** and copy the **Project URL** and the **service_role** key into `.env`.

The service role key bypasses row-level security. Keep it on the server only. Do not put it in any browser page or in GitHub.

## 3. Put the code on GitHub

```bash
git init -b main
git add .
git commit -m "Tripwire backend: FastAPI, Supabase, Vercel"
gh repo create tripwire-backend --private --source . --push
```

`.env` is in `.gitignore`, so secrets stay off GitHub.

## 4. Deploy on Vercel

1. In Vercel, choose **Add New > Project** and import the GitHub repository.
2. Framework preset: **Other**. Leave the build and output settings empty.
3. Under **Environment Variables**, add `SUPABASE_URL`, `SUPABASE_SERVICE_KEY` and `TRIPWIRE_API_KEY`.
4. Deploy. Every push to `main` deploys automatically.

Check the deployment at `https://<your-project>.vercel.app/health`.

## 5. Call the API

```bash
curl -X POST https://<your-project>.vercel.app/v1/accounts \
  -H "X-API-Key: $TRIPWIRE_API_KEY" -H "Content-Type: application/json" \
  -d '{"id":"AC-1001","name":"Asha Rao","kind":"retail","home_city":"Mumbai","opening_balance":250000,"account_age_days":900}'

curl -X POST https://<your-project>.vercel.app/v1/payments \
  -H "X-API-Key: $TRIPWIRE_API_KEY" -H "Content-Type: application/json" \
  -d '{"from_account":"AC-1001","to_account":"M-SPICE","amount":800,"device_id":"D-home","city":"Mumbai","channel":"UPI"}'
```

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Liveness check, no key needed |
| POST | `/v1/accounts` | Create an account |
| GET | `/v1/accounts/{id}` | Read an account |
| POST | `/v1/payments` | Score and record a payment |
| GET | `/v1/payments` | Recent payments |
| GET | `/v1/payments/{id}` | One payment with its factors |
| GET | `/v1/cases` | Cases, optionally `?status=open` |
| GET | `/v1/cases/{id}` | A case with its payments |
| POST | `/v1/cases/{id}/actions` | Body `{"action": "confirm" \| "escalate" \| "clear"}` |
| GET | `/v1/metrics` | Precision, recall and false-positive rate for labelled payments |

## Known limits

- **Cases are linked, not merged.** If two open cases later share an account, they stay separate.
- **Cycle detection** searches 4 hops over the last 30 minutes, so long rings are missed.
- **City coordinates** cover only the cities in `app/service.py`. Add more there.
- **Thresholds** come from environment variables. Changing them needs a redeploy.
- **Authentication** is one shared API key. Use per-user keys or Supabase Auth before opening the API to customers.
